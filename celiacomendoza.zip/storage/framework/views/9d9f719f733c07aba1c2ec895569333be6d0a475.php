<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="container">
            <div class="row">
                <div class="col-md-3 page-sidebar">
                    <?php echo $__env->make('web.parts.adminClient._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="col-md-9 page-content">
                    <div class="inner-box">
                        <h2 class="title-2"><i class="fa fa-shopping-cart"></i> Listado de productos Vendidos </h2>

                        <div style="clear:both"></div>

                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Código Venta</th>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Total</th>
                                    <th>Fecha</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $purcharses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($purchars->num_invoice); ?></td>
                                        <td>
                                            <span data-placement="right" data-toggle="tooltip" data-original-title="<?php echo e($purchars->name); ?>">
                                                <?php echo e(str_limit($purchars->name,30)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($purchars->quantity); ?></td>
                                        <td>$ <?php echo e($purchars->price); ?></td>
                                        <td><?php echo e(Date::parse($purchars->created_at)->format('d/m/Y H:m')); ?></td>
                                        <?php if($purchars->status == 'FINISH'): ?>
                                            <td><span class="label label-default">Finalizada</span></td>
                                        <?php else: ?>
                                            <td><span class="label label-default">Pendiente</span></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div style="clear:both"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminClient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>