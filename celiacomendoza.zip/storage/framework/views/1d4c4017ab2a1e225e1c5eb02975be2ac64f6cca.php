<div class="row m_t40">
    <div class="col-md-9 col-sm-9 col-xs-12">
        <div class="details-heading heading">
            <h2 class="p_b20">Nuestras <span>Ofertas</span></h2>
            <div class="main">
                <ul id="og-grid" class="og-grid">
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="#" data-largesrc="images/listing-services-1-1.jpg"
                               data-title="Restaurant <span>and Bar</span>"
                               data-description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin nec cursus orci, id pulvinar arcu.">
                                <img src="<?php echo e(asset('images/thumbnail/products/'.($offer->photo))); ?>" alt="img01"/>
                                <h4><?php echo e($offer->name); ?></h4>
                                <h5>$ <?php echo e($offer->price); ?></h5>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="add-more text-center">
                    <a href="#">Add More</a>
                </div>
            </div>
        </div>
    </div>
</div>