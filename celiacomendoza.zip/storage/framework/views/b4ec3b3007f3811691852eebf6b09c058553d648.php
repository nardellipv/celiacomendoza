<div class="page-sidebar">
    <!-- START X-NAVIGATION -->
    <ul class="x-navigation">
        <li class="xn-logo">
            <a href="index.html">Admin CM</a>
            <a href="#" class="x-navigation-control"></a>
        </li>
        <li class="xn-title">Menú</li>
        <li class="<?php echo e(request()->is('admin/') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('admin/')); ?>"><span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>
        </li>
        <li class="<?php echo e(request()->is('admin/categorias') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('admin/categorias')); ?>"><span class="fa fa-list"></span> <span class="xn-text">Categorias</span></a>
        </li>
        <li class="<?php echo e(request()->is('admin/blog/list') ? 'active' : ''); ?>">
            <a href="<?php echo e(url('admin/blog/list')); ?>"><span class="fa fa-list"></span> <span class="xn-text">Blog</span></a>
        </li>
    </ul>
</div>