<?php if(count($products) > 0): ?>
    <div class="details-heading heading">
        <h2 class="p_b20">Nuestros <span>Productos</span></h2>
        <div class="main">
            <ul id="og-grid" class="og-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="#">
                        <img src="<?php echo e(asset('images/thumbnail/products/'.($product->photo))); ?>"
                             alt="<?php echo e($product->name); ?>"/>
                        <h4 style="background-color: #0000007a;margin-left: -10px;"><?php echo e($product->name); ?> - $ <?php echo e($product->price); ?></h4>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>