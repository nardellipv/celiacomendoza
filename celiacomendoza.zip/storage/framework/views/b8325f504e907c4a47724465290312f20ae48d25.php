<script src="<?php echo e(asset('webStyle/js/jquery.2.2.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootstrap.min.js')); ?>"></script>




<script src="<?php echo e(asset('webStyle/js/bootsnav.js')); ?>"></script>




<script src="<?php echo e(asset('webStyle/js/functions.js')); ?>"></script>
<span itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
<meta itemprop="addressLocality" content="Mendoza">
<meta itemprop="addressRegion" content="Mendoza">
<meta itemprop="addressCountry" content="Argentina"></span>
<meta itemprop="url" content="https://www.celiacosmendoza.com/">