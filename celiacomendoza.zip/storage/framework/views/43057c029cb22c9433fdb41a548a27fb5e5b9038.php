<?php $__env->startSection('title', 'Post ' . $post->title); ?>
<?php $__env->startSection('meta-description', '✍ Noticia sobre ' . $post->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="blog heading">
                    <h2><?php echo e($post->title); ?></h2>

                    <div class="blog-img">
                        <img src="<?php echo e(asset('images/blog/' . $post->photo)); ?>" alt="<?php echo e($post->title); ?>">
                    </div>

                    <div class="blog-detail">
                        <ul class="blog-admin">
                            <li><i class="fa fa-clock-o"></i><a
                                        href="#"> <?php echo e(Date::parse($post->created_at)->diffForHumans()); ?></a></li>
                        </ul>
                        <p><?php echo $post->body; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>