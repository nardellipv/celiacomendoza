<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta name="description" content="Locales y vendedores de comida y productos para celíacos en mendoza.
    Guía práctica y simple para poder comparar precios y productos, y buscar locales cercanos a sus domicilios ">
    <title>Celiaco Mendoza</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('webStyle/css/master.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('webStyle/css/color-green.css')); ?>">

    <link sizes="72x72" href="<?php echo e(asset('webStyle/ico/apple-icon-72x72.png')); ?>">
    <link sizes="114x114" href="<?php echo e(asset('webStyle/ico/apple-icon-144x144.png')); ?>">
    <link sizes="72x72" href="<?php echo e(asset('webStyle/ico/android-icon-72x72.png')); ?>">
    <link sizes="114x114" href="<?php echo e(asset('webStyle/ico/android-icon-144x144.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('webStyle/ico/apple-icon-72x72.png')); ?>">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <?php echo $__env->make('external.analitycs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('external.pixelFace', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

<!-- LOADER -->
<div class="loader">
    <div class="cssload-svg"><img src="<?php echo e(asset('webStyle/img/42-3.gif')); ?>" alt="image">
    </div>
</div>
<!--LOADER-->

<!-- HEADER -->
<?php echo $__env->make('web.parts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- HEADER -->

<!-- Inner Banner -->
<section id="inner-banner-2">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="inner_banner_2_detail">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner Banner -->

<!-- Popular Listing -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Popular Listing -->

<!-- Footer -->
<?php echo $__env->make('web.parts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->

<script src="<?php echo e(asset('webStyle/js/jquery.2.2.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/jquery.appear.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/jquery-countTo.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootsnav.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/zelect.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/modernizr.custom.26633.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/jquery.gridrotator.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/functions.js')); ?>"></script>
</body>

</html>