<aside>
    <div class="sidebar-modern-inner">
        <div class="block-title ">
            <h5><a href="#">Regiones</a></h5>
        </div>
        <div class="block-content categories-list  list-filter ">
            <ul class="browse-list list-unstyled long-list">
                <?php $__currentLoopData = $allRegion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url('region', $region->slug)); ?>" title="<?php echo e($region->name); ?>"><?php echo e($region->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div style="clear:both"></div>
    </div>
</aside>