<?php $__env->startSection('content'); ?>
    <section id="login-register" class="p_b70 p_t70">

        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#login" aria-controls="login" role="tab"
                                                                  data-toggle="tab">ingresar</a>
                        </li>
                        <li role="presentation"><a href="#registerd" aria-controls="registerd" role="tab"
                                                   data-toggle="tab">Registrarse</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Tab panes -->
        <div class="tab-content">

            <div role="tabpanel" class="tab-pane fade in active" id="login">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="login-register-bg">

                                <div class="row">

                                    <div class="col-md-7 col-sm-7 col-xs-12">
                                        <div class="heading">
                                            <h2>Ingresar</h2>
                                        </div>

                                        <form method="POST" action="<?php echo e(route('login')); ?>"
                                              aria-label="<?php echo e(__('Login')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <input id="email" type="email"
                                                       class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" placeholder="Email"
                                                       required autofocus>

                                                <?php if($errors->has('email')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                         <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <input id="password" type="password"
                                                       class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                       name="password" placeholder="Contraseña" required>

                                                <?php if($errors->has('password')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary btn-block">
                                                    <?php echo e(__('Login')); ?>

                                                </button>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-check-input" type="checkbox" name="remember"
                                                       id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('Recordarme')); ?>

                                                </label> <a href="#">|</a>
                                                <a href="<?php echo e(route('password.request')); ?>">
                                                    <?php echo e(__('¿Olvidá mi contraseña?')); ?>

                                                </a>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="col-md-5 col-sm-5 col-xs-12">
                                        <div class="social-register-bg">

                                            <h2>Registrarte como vendedor </h2>

                                            <p>Si vendes alimentos sin Tacc o sos proveedor de productos sin gluten o
                                                solamente haces viandas para celíacos, en toda la provincia de Mendoza y
                                                queres llegar a más clientes, te invitamos a registrarte en nuestra
                                                web.</p>
                                            <p>Es simple, llega a todo Mendoza y lo más importante es GRATIS!!!</p>
                                            <p>Registrate y empeza a vender</p>


                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div role="tabpanel" class="tab-pane fade" id="registerd">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="login-register-bg">

                                <div class="row">

                                    <div class="col-md-7 col-sm-7 col-xs-12">
                                        <div class="heading">
                                            <h2>Crear una nueva <span>cuenta</span></h2>
                                        </div>

                                        <form method="POST" action="<?php echo e(route('register')); ?>"
                                              aria-label="<?php echo e(__('Register')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <input id="name" type="text"
                                                       class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                       name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre"
                                                       required autofocus>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group">
                                                <input id="name" type="text"
                                                       class="form-control<?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>"
                                                       name="lastname" value="<?php echo e(old('lastname')); ?>"
                                                       placeholder="Apellido" required autofocus>
                                                <small id="passwordHelpBlock" class="text text-info">
                                                    No será público
                                                </small>

                                                <?php if($errors->has('lastname')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="form-group">
                                                <input id="email" type="email"
                                                       class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" placeholder="Email"
                                                       required>

                                                <?php if($errors->has('email')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <input id="password" type="password"
                                                       class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                       name="password" placeholder="Password" required>
                                                <small id="passwordHelpBlock" class="text text-info">
                                                    Mínimo 6 caracteres
                                                </small>

                                                <?php if($errors->has('password')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <input id="password-confirm" type="password" class="form-control"
                                                       name="password_confirmation" placeholder="Confirmar Password"
                                                       required>
                                            </div>


                                    </div>

                                    <div class="col-md-5 col-sm-5 col-xs-12">
                                        <div class="heading">
                                            <h2>Datos del <span>comercio</span></h2>
                                        </div>
                                        <div class="form-group">
                                            <input id="name" type="text"
                                                   class="form-control<?php echo e($errors->has('nameCommerce') ? ' is-invalid' : ''); ?>"
                                                   name="nameCommerce" value="<?php echo e(old('nameCommerce')); ?>"
                                                   placeholder="Nombre del comercio"
                                                   required autofocus>
                                            <small id="passwordHelpBlock" class="text text-info">
                                                Ten en cuenta que NO podrás cambiarlo
                                            </small>


                                            <?php if($errors->has('nameCommerce')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('nameCommerce')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group">
                                            <select id="inputState" class="form-control" name="region_id" required>
                                                <option selected value="">Elegir región...</option>
                                                <option disabled>---------------------------------------------
                                                </option>
                                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <input type="checkbox" class="custom-control-input"
                                               id="customControlAutosizing" required>
                                        <label for="customControlAutosizing"> <span
                                                    class="custom-control-description"> Acepto <a
                                                        href="<?php echo e(url('terminos')); ?>">Términos y condiciones</a> </span></label>
                                    </div>

                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Registrarse')); ?>

                                        </button>
                                    </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>