<?php if(count($errors) > 0): ?>
    <section id="directory-category" class="p_b70 p_t70">
        <div class="container">
            <div class="row">
                <div class="col-md-12 directory-category-heading">
                    <h4>Revise los siguientes <span>Errores</span></h4>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><i class="fa fa-ban"></i> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>