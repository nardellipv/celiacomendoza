<?php $__env->startSection('meta-description','👉 Enterate de lo último en temas de celiaquia. Publicamos contenido semanalmente para que celíacos Mendocinos este actualizados constantemente.'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog heading">
            <h2><a href="<?php echo e(url('blog', $post->slug)); ?>"><?php echo e($post->title); ?></a></h2>
            <div class="blog-img">
                <img src="<?php echo e(asset('images/blog/'.$post->photo)); ?>" alt="image">
            </div>
            <div class="blog-detail">
                <ul class="blog-admin">
                    <li><i class="fa fa-clock-o"></i><a href="#"> <?php echo e(Date::parse($post->created_at)->diffForHumans()); ?></a></li>
                </ul>
                <p><?php echo str_limit($post->body, 200); ?> </p>
                <a href="<?php echo e(url('blog', $post->slug)); ?>" class="blog-btn">Leer mas</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="bs-example" data-example-id="disabled-active-pagination">
        <nav aria-label="...">
            <ul class="pagination">
                <?php echo e($posts->render()); ?>

            </ul>
        </nav>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>