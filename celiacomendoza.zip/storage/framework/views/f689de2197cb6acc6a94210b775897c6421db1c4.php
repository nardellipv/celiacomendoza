<header id="main_header_2">
    <div id="header-top">
        <div class="container">
            <div class="row">

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="top-contact">
                        <p>Para más información: <span itemprop="email">info@celiacosmendoza.com</span>
                        </p>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="top_right_links2">
                        <ul class="top_links">
                            <li><a href="<?php echo e(url('cliente-perfil')); ?>"><i class="fa fa-user-o" aria-hidden="true"></i>
                                    Perfíl</a></li>
                            <?php if(Auth::check()): ?>
                                <li>Bienvenido <?php echo e(Auth::user()->name); ?></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-lock" aria-hidden="true"></i> Ingresar
                                        /
                                        Registrarse</a></li>
                            <?php endif; ?>
                        </ul>
                        <?php if(Auth::check()): ?>
                            <div class="add-listing"><a href="<?php echo e(url('cliente-perfil/product/create')); ?>"><i
                                            class="fa fa-plus" aria-hidden="true"></i> Subir producto</a></div>
                        <?php else: ?>
                            <div class="add-listing"><a href="<?php echo e(url('cliente-perfil/product/create')); ?>"><i
                                            class="fa fa-plus" aria-hidden="true"></i> Subir local</a></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="top_right_links2-bg"></div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('web.parts._menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>