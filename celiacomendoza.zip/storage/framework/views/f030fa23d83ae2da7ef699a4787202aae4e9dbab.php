<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12 page-content">
                <div class="category-list ">
                <?php echo $__env->make('web.parts.alerts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!--/.tab-box-->
                    <div class="listing-filter">
                        <div class="pull-left col-xs-6">
                            <div class="breadcrumb-list">
                                <span>Listado de productos</span>
                            </div>
                        </div>
                        <div class="pull-right col-xs-6 text-right listing-view-action"><span
                                    class="list-view active"><i class="  icon-th"></i></span> <span
                                    class="compact-view"><i class=" icon-th-list  "></i></span> <span
                                    class="grid-view "><i class=" icon-th-large "></i></span></div>
                        <div style="clear:both"></div>
                    </div>
                    <!--/.listing-filter-->

                    <div class="tab-content">
                        <div class="tab-pane  active " id="alladslist">
                            <div class="adds-wrapper row no-margin">
                                <?php $__currentLoopData = $listProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-list">
                                        <div class="row">
                                            <div class="col-md-2 no-padding photobox">
                                                <div class="add-image">
                                                    <img src="<?php echo e(asset('images/thumbnail/products/'.($listProduct->photo))); ?>">
                                                </div>
                                            </div>
                                            <!--/.photobox-->
                                            <div class="col-md-7 add-desc-box">
                                                <div class="ads-details">
                                                    <h5 class="add-title">
                                                        <?php echo e($listProduct->name); ?>

                                                    </h5>
                                                </div>
                                                <div class="card-event-info">
                                                    <p class="event-time"><i
                                                                class="fa icon-restaurant"></i> <?php echo e($commerce->name); ?>

                                                    </p>
                                                    <p class="event-location"><i class="fa icon-location"></i>
                                                        <a class="location"
                                                           href=""><?php echo e($commerce->address); ?> <?php echo e($commerce->number); ?> </a>
                                                    </p>
                                                </div>
                                            </div>
                                            <!--/.add-desc-box-->
                                            <div class="col-md-3 text-right  price-box">
                                                <h2 class="item-price"> $ <?php echo e($listProduct->price); ?> </h2>
                                                <p>Cantidad: <strong><?php echo e($listProduct->quantity); ?></strong></p>
                                                <a href="<?php echo e(url('borrar', array($listProduct->commerce_id, $listProduct->id))); ?>"
                                                   class="btn btn-danger  btn-sm make-favorite">
                                                    <i class="fa fa-trash"></i>
                                                    <span>Eliminar</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>

                    <div class="tab-box save-search-bar text-right"
                         style="padding:  20px; background-color:  yellowgreen;">
                        <div class="row">
                            <div class="col-sm-10">
                                Cantidad Productos:
                            </div>
                            <div class="col-sm-2">
                                <h2 class="item-price"> <?php echo e($sumQuantity); ?> </h2>
                            </div>
                            <div class="col-sm-10">
                                total:
                            </div>
                            <div class="col-sm-2">
                                <h2 class="item-price"> $ <?php echo e($sumTotal); ?> </h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-box save-search-bar text-center">
                    <a class="btn btn-secondary" href="<?php echo e(url('/')); ?>">Continuar Comprando</a>
                </div>
            </div>

            <div class="pagination-bar text-center">
                <nav aria-label="Page navigation " class="d-inline-b">
                    
                </nav>
            </div>
            <div class="post-promo text-center offset-1">
                <h2> Al comprar </h2>
                <h5>Al confirmar esta compra usted deberá buscarla y abonarla en el local
                    comercial. Para mayor información por favor
                    comuniquese con el local de la compra.</h5>
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12  col-sm-12">
                            <?php echo Form::open(['method' => 'POST','url' => ['checkout']]); ?>

                            <?php echo e(csrf_field()); ?>

                            <?php if($cartCount > 0): ?>
                                <?php $__currentLoopData = $listProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$listProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <input type="text" name="nameCommerce[<?php echo e($key); ?>]"
                                           value="<?php echo e($listProduct->commerce->name); ?>" id="name" readonly required
                                           hidden/>
                                    
                                    <input type="text" name="mailCommerce[<?php echo e($key); ?>]"
                                           value="<?php echo e($listProduct->commerce->user->email); ?>" id="name" readonly
                                           required
                                           hidden/>
                                    
                                    <input type="text" name="phoneCommerce[<?php echo e($key); ?>]"
                                           value="<?php echo e($listProduct->commerce->phone); ?>" id="name" readonly required
                                           hidden/>
                                    
                                    <input type="text" name="addressCommerce[<?php echo e($key); ?>]"
                                           value="<?php echo e($listProduct->commerce->address); ?>" id="name" readonly required
                                           hidden/>
                                    
                                    <input type="text" name="products[]"
                                           value="<?php echo e($listProduct->name); ?>" id="name" readonly required hidden/>
                                    
                                    <input type="text" name="productsPhoto[]"
                                           value="<?php echo e($listProduct->photo); ?>" id="name" readonly required hidden/>
                                    
                                    <input type="text" name="productsPrice[]"
                                           value="<?php echo e($listProduct->price); ?>" id="name" readonly required hidden/>
                                    
                                    <input type="text" name="total"
                                           value="<?php echo e($sumTotal); ?>" id="name" readonly required hidden/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <input type="text" name="numInvoice"
                                       value="<?php echo e($listProduct->num_invoice); ?>" id="name" readonly required hidden/>
                            <?php endif; ?>

                            <fieldset>
                            <div class="col-sm-6 offset-3">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="name" id="name"
                                           placeholder="Nombre" value="<?php echo e(old('name')); ?>" required/>
                                </div>
                            </div>
                            <div class="col-sm-6 offset-3 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="lastname" id="lastname"
                                           placeholder="Apellido" value="<?php echo e(old('lastname')); ?>" required/>
                                </div>
                            </div>
                            <div class="col-sm-6 offset-3 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="phone" id="phone"
                                           placeholder="Teléfono" value="<?php echo e(old('phone')); ?>" required/>
                                </div>
                            </div>
                            <div class="col-sm-6 offset-3 ">
                                <div class="form-group">
                                    <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" id="email"
                                           placeholder="Email" required/>
                                </div>
                            </div>

                            <div class="col-md-6 offset-3">
                                <?php if($cartCount > 0): ?>
                                    <button type="submit" id="submit-message" class="btn btn-primary btn-block">
                                        Procesar Compra
                                    </button>
                                <?php else: ?>
                                    <button type="submit" id="submit-message" class="btn btn-primary btn-block"
                                            disabled>
                                        Procesar Compra
                                    </button>
                                <?php endif; ?>
                            </div>

                            <?php echo Form::Close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

