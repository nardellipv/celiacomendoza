<div class="details-heading heading">
    <h2 class="p_b40">Un poco sobre <span>Nosotros</span></h2>
    <p><?php echo e($commerce->about); ?></p>
    <ul class="social-register-icon">
        <?php if($commerce->facebook): ?>
        <li><a href="https://www.facebook.com/<?php echo e($commerce->facebook); ?>" target="_blank"><i class="fa fa-facebook"></i>
                Facebook</a>
        </li>
        <?php endif; ?>
    </ul>
</div>