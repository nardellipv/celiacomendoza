<div class="details-heading heading">
    <h2 class="p_b20">Nuestras <span>Redes</span></h2>
    <div class="main text-center">
        <div class="fb-page" data-href="https://www.facebook.com/<?php echo e($commerce->facebook); ?>/"
             data-tabs="timeline" data-width="1000" data-small-header="false"
             data-adapt-container-width="false" data-hide-cover="false"
             data-show-facepile="true">
            <blockquote cite="https://www.facebook.com/<?php echo e($commerce->facebook); ?>/"
                        class="fb-xfbml-parse-ignore"><a
                        href="https://www.facebook.com/<?php echo e($commerce->facebook); ?>/"><?php echo e($commerce->name); ?></a>
            </blockquote>
        </div>
    </div>
</div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- CeliacosCommerceDown -->
<ins class="adsbygoogle"
     style="display:inline-block;width:468px;height:60px"
     data-ad-client="ca-pub-7543412924958320"
     data-ad-slot="8594503608"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
</script>