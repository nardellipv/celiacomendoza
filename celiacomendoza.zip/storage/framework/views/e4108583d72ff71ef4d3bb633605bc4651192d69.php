<aside>
    <div class="sidebar-modern-inner">
        <div class="block-title has-arrow sidebar-header">
            <h5>Categorías</h5>
        </div>
        <div class="block-content categories-list  list-filter ">
            <ul class=" list-unstyled">
                <?php $__currentLoopData = $listCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('listado-categoria', array($commerce->slug, $listCategory->id))); ?>"><span
                                    class="title"><?php echo e($listCategory->name); ?></span>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="block-title has-arrow ">
            <h5>Últimos Productos</h5>
        </div>
        <div class="block-content locations-list  list-filter ">
            <?php echo $__env->make('web.parts._shopLastItems', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</aside>