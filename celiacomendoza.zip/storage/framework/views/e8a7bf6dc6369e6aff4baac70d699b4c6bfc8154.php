<div class="details-heading heading">
    <h2 class="p_b20">Nuestros <span>Descatados</span></h2>
    <div class="main">
        <ul id="og-grid" class="og-grid">
            <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="#" data-largesrc="<?php echo e(asset('images/thumbnail/products/'.($highlight->photo))); ?>"
                       data-title="Restaurant <span>and Bar</span>"
                       data-description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin nec cursus orci, id pulvinar arcu.">
                        <img src="<?php echo e(asset('images/thumbnail/products/'.($highlight->photo))); ?>" alt="img01"/>
                        <h4><?php echo e($highlight->name); ?></h4>
                        <h5>$ <?php echo e($highlight->price); ?></h5>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="add-more text-center">
            <a href="#">Add More</a>
        </div>
    </div>
</div>
