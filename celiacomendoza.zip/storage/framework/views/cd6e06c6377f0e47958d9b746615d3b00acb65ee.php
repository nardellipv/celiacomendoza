<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.parts._widget', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.parts._listUsers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.parts._listProduct', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type='text/javascript' src='<?php echo e(asset('adminStyle/js/plugins/icheck/icheck.min.js')); ?>'></script>
    <script type="text/javascript"
            src="<?php echo e(asset('adminStyle/js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>