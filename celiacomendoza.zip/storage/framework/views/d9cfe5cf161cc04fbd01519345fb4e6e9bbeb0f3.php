<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Productos</h3>
                    <a href="<?php echo e(route('blog.create')); ?>" type="button" class="btn btn-default btn-rounded pull-right">Agregar Nuevo Post</a>
                </div>
                <div class="panel-body">
                    <table class="table datatable">
                        <thead>
                        <tr>
                            <th>Titulo</th>
                            <th>Cuerpo</th>
                            <th>Status</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($post->title); ?></td>
                                <td><?php echo e(str_limit($post->body, 100)); ?></td>
                                <td><?php echo e($post->status); ?></td>
                                <td>
                                   
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type='text/javascript' src='<?php echo e(asset('adminStyle/js/plugins/icheck/icheck.min.js')); ?>'></script>
    <script type="text/javascript"
            src="<?php echo e(asset('adminStyle/js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>