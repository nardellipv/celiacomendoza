<?php $__currentLoopData = $lastProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product">
        <img src="<?php echo e(asset('images/thumbnail/products/'.$lastProduct->photo)); ?>" alt="product" width="20%"/>
        <div class="product-desc">
            <div class="product-title">
                <a href="<?php echo e(url('producto', array($commerce->slug, $lastProduct->id))); ?>"><?php echo e(str_limit($lastProduct->name,25)); ?></a>
            </div>
            <div class="product-meta">
                <?php if(!$lastProduct->offer): ?>
                    <span class="color-theme">$<?php echo e($lastProduct->price); ?></span>
                <?php else: ?>
                    <span class="color-theme">$<strike><?php echo e($lastProduct->price); ?></strike></span>
                    <span class="color-theme">$<?php echo e($lastProduct->offer); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>