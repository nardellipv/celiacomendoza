<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php echo $__env->make('layouts._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
<?php echo $__env->make('external.addthis', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- LOADER -->
<div class="loader">
    <div class="cssload-svg"><img src="<?php echo e(asset('webStyle/img/42-3.gif')); ?>" alt="image">
    </div>
</div>
<!--LOADER-->

<!-- HEADER -->
<?php echo $__env->make('web.parts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- HEADER  -->

<!-- Inner Banner -->
<section id="inner-banner-2">
    <div class="container">
        <div class="row">

            <div class="col-md-12 text-center">
                <div class="inner_banner_2_detail">
                    <h1>Almacen del Celíaco</h1>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- Inner Banner -->

<!-- Blog -->
<section id="blog" class="p_b70 p_t70 bg_lightgry">
    <div class="container">
        <div class="row">

            <div class="col-md-9 col-sm-9 col-xs-12">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <div class="col-md-3 col-sm-3 col-xs-12">
                <?php echo $__env->make('web.parts._asideBlog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Listing Details Heading -->

<!-- Footer -->
<?php echo $__env->make('web.parts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->

<script src="<?php echo e(asset('webStyle/js/jquery.2.2.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/jquery.appear.js')); ?>"></script>


<script src="<?php echo e(asset('webStyle/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootsnav.js')); ?>"></script>







<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAOBKD6V47-g_3opmidcmFapb3kSNAR70U"></script>

<script src="<?php echo e(asset('webStyle/js/functions.js')); ?>"></script>
<script>
    $(function () {
        Grid.init();
    });
</script>
</body>

</html>