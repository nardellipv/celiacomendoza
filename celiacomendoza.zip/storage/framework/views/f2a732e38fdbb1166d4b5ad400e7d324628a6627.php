<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php echo $__env->make('layouts._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>
<div id="fb-root"></div>
<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = 'https://connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v3.1';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<!-- LOADER -->
<div class="loader">
    <div class="cssload-svg"><img src="<?php echo e(asset('webStyle/img/42-3.gif')); ?>" alt="image">
    </div>
</div>
<!--LOADER-->

<!-- HEADER -->
<?php echo $__env->make('web.parts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- HEADER  -->

<!-- Inner Banner -->
<section id="inner-banner-2">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="inner_banner_2_detail">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner Banner -->

<!-- Listing Details Heading -->
<section id="listing-details" class="p_b70 p_t70">
    <div class="container">
        <?php echo $__env->yieldContent('contentAbout'); ?>
        <div class="row m_t40">
            <div class="col-md-8 col-sm-8 col-xs-12">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
                <?php if(Request::is('region/*')): ?>
                    <?php echo $__env->make('web.parts._region', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('web.parts._asideCommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- Listing Details Heading -->

<!-- Footer -->
<?php echo $__env->make('web.parts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->

<script src="<?php echo e(asset('webStyle/js/jquery.2.2.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootstrap.min.js')); ?>"></script>





<script src="<?php echo e(asset('webStyle/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('webStyle/js/bootsnav.js')); ?>"></script>



<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyAOBKD6V47-g_3opmidcmFapb3kSNAR70U"></script>

<script src="<?php echo e(asset('webStyle/js/functions.js')); ?>"></script>
<script>
    $(function () {
        Grid.init();
    });
</script>

</body>

</html>