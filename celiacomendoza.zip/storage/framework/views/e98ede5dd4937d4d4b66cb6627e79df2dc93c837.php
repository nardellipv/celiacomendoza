<div class="row">
    <div class="col-md-12">
        <?php echo $__env->make('web.parts.alerts.successVote', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="details-heading heading">
            <div class="row">
                <div class="col-md-8">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-4"><h3 style="color: #1fb7a6"><?php echo e($commerce->name); ?></h3></div>
                            <div class="col-sm-offset-2 col-sm-2" style="font-size: 1.1em;">
                                <i class="fa fa-thumbs-o-up" style="color:green"></i> <?php echo e($commerce->votes_positive); ?>

                                <i class="fa fa-thumbs-o-down" style="color:red"></i> <?php echo e($commerce->votes_negative); ?>

                                <i class="fa fa-question-circle-o red-tooltip" data-toggle="tooltip"
                                   title="Votos de la comunidad" style="font-size: 1.3em;color: black;"></i>
                            </div>
                        </div>
                    </div>
                    <div class="details-heading-address">
                        <?php if($commerce->address): ?>
                            <p><i class="fa fa-map-marker" aria-hidden="true"></i> Dirección - <?php echo e($commerce->address); ?>

                            </p>
                        <?php endif; ?>
                        <br>
                        <?php if($commerce->address): ?>
                            <p><i class="fa fa-map-o" aria-hidden="true"></i>Localidad - <?php echo e($commerce->region->name); ?>

                            </p>
                        <?php else: ?>
                            <p><i class="fa fa-map-o" aria-hidden="true"></i>Localidad - Sin Localidad</p>
                        <?php endif; ?>
                        <ul>
                            <?php if($commerce->phone): ?>
                                <li><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($commerce->phone); ?></li>
                            <?php endif; ?>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e($commerce->user->email); ?></li>
                            <li><i class="fa fa-user" aria-hidden="true"></i> <?php echo e($commerce->user->name); ?></li>
                        </ul>
                        <br><br>
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-3"><p>¿Comó te fue con <b><?php echo e($commerce->name); ?></b>?</p></div>
                                <div class="col-sm-1"><a href="<?php echo e(route('positive', $commerce->slug)); ?>"><i
                                                class="fa fa-thumbs-o-up fa-2x"></i></a></div>
                                <div class="text-left"><a href="<?php echo e(route('negative', $commerce->slug)); ?>"><i
                                                class="fa fa-thumbs-o-down fa-2x"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <?php if($commerce->logo): ?>
                        <img src="<?php echo e(asset('images/thumbnail/logo/'.($commerce->logo))); ?>"
                             alt="<?php echo e($commerce->name); ?>">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/nodisp.png')); ?>" alt="<?php echo e($commerce->name); ?>">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- CeliacosCommerce -->
<ins class="adsbygoogle"
     style="display:inline-block;width:970px;height:90px"
     data-ad-client="ca-pub-7543412924958320"
     data-ad-slot="2008790249"></ins>
<script>
    (adsbygoogle = window.adsbygoogle || []).push({});
</script>