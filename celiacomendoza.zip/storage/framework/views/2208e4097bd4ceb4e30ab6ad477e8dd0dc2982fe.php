<?php $__env->startSection('content'); ?>
    <section id="login-register" class="p_b70 p_t70">

        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#login" aria-controls="reset" role="tab"
                                                                  data-toggle="tab">Pedir nueva contraseña</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Tab panes -->
        <div class="tab-content">

            <div role="tabpanel" class="tab-pane fade in active" id="reset">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="login-register-bg">

                                <div class="row">

                                    <div class="col-md-7 col-sm-7 col-xs-12">
                                        <div class="heading">
                                            <h2>Resetear contraseña</h2>
                                        </div>
                                        <form method="POST" action="<?php echo e(route('password.email')); ?>"
                                              aria-label="<?php echo e(__('Reset Password')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="sender-email" class="control-label">Email:</label>

                                                <div class="input-icon"><i class="icon-user fa"></i>
                                                    <input id="email" type="email"
                                                           class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                           name="email" value="<?php echo e(old('email')); ?>" placeholder="Email"
                                                           required>

                                                    <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary btn-lg btn-block">
                                                    <?php echo e(__('Enviar mi contraseña')); ?>

                                                </button>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="col-md-5 col-sm-5 col-xs-12">
                                        <div class="social-register-bg">

                                            <h2>Registrarte como vendedor </h2>

                                            <p>Si vendes alimentos sin Tacc o sos proveedor de productos sin gluten o
                                                solamente haces viandas para celíacos, en toda la provincia de Mendoza y
                                                queres llegar a más clientes, te invitamos a registrarte en nuestra
                                                web.</p>
                                            <p>Es simple, llega a todo Mendoza y lo más importante es GRATIS!!!</p>
                                            <p>Registrate y empeza a vender</p>


                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>