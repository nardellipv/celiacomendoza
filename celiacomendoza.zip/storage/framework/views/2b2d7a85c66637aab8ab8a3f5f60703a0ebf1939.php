<?php $__env->startSection('content'); ?>
    <?php if(Request::is('cliente-perfil')): ?>
        <?php echo $__env->make('web.parts.adminClient._personal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <?php if(Request::is('cliente-perfil/activos')): ?>
        <?php echo $__env->make('web.parts.adminClient._productsAvailable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <?php if(Request::is('cliente-perfil/desactivos')): ?>
        <?php echo $__env->make('web.parts.adminClient._productsDisable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminClient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>