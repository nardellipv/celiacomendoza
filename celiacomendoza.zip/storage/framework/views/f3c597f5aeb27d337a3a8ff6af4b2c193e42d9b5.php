<div class="main-container">
    <div class="container">
        <div class="row">
            <!-- this (.mobile-filter-sidebar) part will be position fixed in mobile version -->
            <div class="col-md-3 page-sidebar mobile-filter-sidebar">
                <aside>
                    <?php echo $__env->make('web.parts._shopCategories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </aside>
            </div>
            <div class="col-md-9 page-content col-thin-left">
                <div class="category-list ">
                    <div class="listing-filter">
                        <div class="pull-left col-xs-6">
                            <div class="breadcrumb-list"><a href="<?php echo e(url('listado', $commerce->slug)); ?>"><i
                                            class="fa fa-arrow-circle-left fa-lg"></i> Volver al listado</a>
                            </div>
                        </div>
                        <div class="pull-right col-xs-6 text-right listing-view-action"><span
                                    class="list-view active"><i class="  icon-th"></i></span> <span
                                    class="compact-view"><i class=" icon-th-list  "></i></span> <span
                                    class="grid-view "><i class=" icon-th-large "></i></span></div>
                        <div style="clear:both"></div>
                    </div>

                    <div class="tab-content">
                        <div class="tab-pane  active " id="alladslist">
                            <div class="adds-wrapper row no-margin">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item-list">
                                        <div class="row">
                                            <div class="col-md-2 no-padding photobox">
                                                <div class="add-image">
                                                    <a href="<?php echo e(url('producto', array($commerce->slug, $product->id))); ?>">
                                                        <img class="thumbnail no-margin" src="<?php echo e(asset('images/thumbnail/products/'.($product->photo))); ?>"
                                                             alt="img">
                                                    </a>
                                                </div>
                                            </div>
                                            <!--/.photobox-->
                                            <div class="col-md-7 add-desc-box">
                                                <div class="ads-details">
                                                    <h5 class="add-title">
                                                        <?php echo e($product->name); ?>

                                                    </h5>
                                                </div>
                                                <div class="card-event-info">
                                                    <p class="event-time"><i
                                                                class="fa icon-food"></i> <?php echo e($product->category->name); ?>

                                                    </p>
                                                    <p class="event-location"><i class="fa icon-location"></i>
                                                        <a class="location"
                                                           href=""><?php echo e(str_limit($product->description,100)); ?> </a>
                                                    </p>
                                                </div>
                                            </div>
                                            <!--/.add-desc-box-->
                                            <div class="col-md-3 text-right  price-box">
                                                <?php if(!$product->offer): ?>
                                                    <h2 class="item-price"> $ <?php echo e($product->price); ?> </h2>
                                                <?php else: ?>
                                                    <h2 class="item-price">
                                                        <del> $ <?php echo e($product->price); ?></del>
                                                    </h2>
                                                    <h2 class="item-price"> $ <?php echo e($product->offer); ?> </h2>
                                                <?php endif; ?>

                                                <a href="<?php echo e(url('producto', array($commerce->slug, $product->id))); ?>"
                                                   class="btn btn-secondary  btn-sm make-favorite"> <i
                                                            class="fa fa-eye"></i> <span>Detalle</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pagination-bar text-center">
                    <nav aria-label="Page navigation " class="d-inline-b">
                        <?php echo e($products->render()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>