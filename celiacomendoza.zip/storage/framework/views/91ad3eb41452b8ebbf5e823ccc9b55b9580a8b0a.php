<div class="details-heading heading">

    <h2 class="p_b20">Más información de <span><?php echo e($commerce->name); ?></span></h2>

    <div class="panel-group m_t40" id="accordion" role="tablist" aria-multiselectable="true">

        <div class="panel panel-default">

            <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"
                       aria-expanded="false" aria-controls="collapseOne" class="collapsed">
                        Medios de pago
                    </a>
                </h4>
            </div>

            <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                    <?php $__currentLoopData = $commercePayment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($payment->payment->photo)); ?>" style="width: auto;">&nbsp;&nbsp;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="panel panel-default">

            <div class="panel-heading" role="tab" id="headingTwo">
                <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsetwo"
                       aria-expanded="false" aria-controls="collapsetwo" class="collapsed">
                        Caracteristicas
                    </a>
                </h4>
            </div>

            <div id="collapsetwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo"
                 aria-expanded="false" style="height: 0px;">
                <div class="panel-body">
                    <?php $__currentLoopData = $characteristicCommerces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $characteristicCommerce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset($characteristicCommerce->characteristic->photo)); ?>"
                             style="width: auto;"> <?php echo e($characteristicCommerce->characteristic->name); ?> &nbsp;&nbsp;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>