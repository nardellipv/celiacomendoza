<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php echo $__env->make('layouts._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<!-- LOADER -->
<div class="loader">
    <div class="cssload-svg"><img src="<?php echo e(asset('webStyle/img/42-3.gif')); ?>" alt="image">
    </div>
</div>
<!--LOADER-->

<!-- HEADER -->
<?php echo $__env->make('web.parts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Inner Banner -->
<section id="inner-banner-2">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="inner_banner_2_detail">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Inner Banner -->

<!-- Popular Listing -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Popular Listing -->

<!-- Footer -->
<?php echo $__env->make('web.parts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->

<?php echo $__env->make('layouts._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>