<div class="tab-content">
    <div role="tabpanel" class="tab-pane fade  in active">
        <div class="row">
            <?php $__currentLoopData = $commerces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commerce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="popular-listing-box">
                        <div class="popular-listing-img">
                            <?php if($commerce->logo): ?>
                                <figure class="effect-ming"><img
                                            src="<?php echo e(asset('images/thumbnail/logo/'.($commerce->logo))); ?>"
                                            class="img-responsive" alt="<?php echo e($commerce->name); ?>">
                                </figure>
                            <?php else: ?>
                                <figure class="effect-ming"><img src="<?php echo e(asset('images/nodisp.png')); ?>"
                                                                 alt="<?php echo e($commerce->name); ?>">
                                </figure>
                            <?php endif; ?>
                        </div>
                        <div class="popular-listing-detail">
                            <h3>
                                <a href="<?php echo e(url('catalogo', $commerce->slug)); ?>"><?php echo e(ucfirst(str_limit($commerce->name,15))); ?></a>
                            </h3>
                            <?php if($commerce->address): ?>
                                <p><?php echo e(str_limit($commerce->address, 20)); ?></p>
                            <?php else: ?>
                                <p>Local sin dirección</p>
                            <?php endif; ?>
                            <p class="text text-center"><i class="fa fa-thumbs-o-up"
                                                           style="color:green"></i> <?php echo e($commerce->votes_positive); ?>

                                &nbsp;&nbsp;&nbsp;<i class="fa fa-thumbs-o-down"
                                                     style="color:red"></i> <?php echo e($commerce->votes_negative); ?></p>
                        </div>
                        <?php if(!empty($commerce->region->name)): ?>
                            <div class="popular-listing-add"><span><i class="fa fa-map-marker"
                                                                      aria-hidden="true"></i> <?php echo e($commerce->region->name); ?></span>
                            </div>
                        <?php else: ?>
                            <div class="popular-listing-add"><span><i class="fa fa-map-marker"
                                                                      aria-hidden="true"></i> Sin localidad</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<div class="bs-example" data-example-id="disabled-active-pagination">
    <nav aria-label="...">
        <ul class="pagination">
            <?php echo $commerces->render(); ?>

        </ul>
    </nav>
</div>
<div id="call-to-action2">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 call-to-action-text">
                <p>Realizas comidas sin tacc ¡No esperes más y registrate! Ofrece tus productos a todos
                    los mendocinos que posee la <b>celiaquía</b>.</p>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12 call-to-action-bttn">
                <a href="<?php echo e(url('login')); ?>">Registrate</a>
            </div>
        </div>
    </div>
</div>