<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9 page-content col-thin-right">
                <div class="inner inner-box ads-details-wrapper">
                    <h2> <?php echo e($product->name); ?> </h2>
                    <div class="ads-image">
                        <?php if(!$product->offer): ?>
                            <h1 class="pricetag"> $ <?php echo e($product->price); ?></h1>
                        <?php else: ?>
                            <h1 class="pricetag"> $ <?php echo e($product->offer); ?></h1>
                        <?php endif; ?>
                        
                        <img src="<?php echo e(asset('images/' . $product->commerce->name . '-' . $product->commerce->id . '/products/' . $product->photo)); ?>">
                    </div>
                    <!--ads-image-->

                    <div class="Ads-Details">
                        <h5 class="list-title"><strong>Detalles</strong></h5>

                        <div class="row">
                            <div class="ads-details-info col-md-8">
                                <p><?php echo e($product->description); ?></p>
                            </div>
                            <div class="col-md-4">
                                <aside class="panel panel-body panel-details">
                                    <ul>
                                        <li>
                                            <?php if(!$product->offer): ?>
                                                <p class=" no-margin "><strong>Precio:</strong>$ <?php echo e($product->price); ?>

                                                </p>
                                            <?php else: ?>
                                                <p class=" no-margin ">
                                                    <strong>Precio:</strong><strike>$ <?php echo e($product->price); ?></strike></p>
                                                <p class=" no-margin "><strong>Precio
                                                        Oferta:</strong>$ <?php echo e($product->offer); ?></p>
                                            <?php endif; ?>
                                        </li>
                                        <li>
                                            <p class="no-margin">
                                                <strong>Categoría:</strong> <?php echo e($product->category->name); ?></p>
                                        </li>
                                    </ul>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-3  page-sidebar-right">
                <aside>
                    <div class="card card-user-info sidebar-card">
                        <div class="block-cell user">

                            <div class="cell-media">
                                <?php if($commerce->logo): ?>
                                    <img src="<?php echo e(asset('images/thumbnail/logo/'.($commerce->logo))); ?>" alt="logo">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/nodisp.png')); ?>" alt="sin logo">
                                <?php endif; ?>
                            </div>
                            <div class="cell-content">
                                <h5 class="title">Local</h5>
                                <span class="name"><?php echo e($commerce->name); ?></span>
                            </div>
                        </div>
                        <div class="card-content">
                            <div class="card-body text-left">
                                <div class="grid-col">
                                    <div class="col from">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span>Ubicación</span>
                                    </div>
                                    <div class="col to">
                                        <span><?php echo e($commerce->region->name); ?></span>
                                    </div>
                                </div>

                                <div class="grid-col">
                                    <div class="col from">
                                        <i class="fas fa-user"></i>
                                        <span>Dirección</span>
                                    </div>
                                    <div class="col to">
                                        <span><?php echo e($commerce->address); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="ev-action">
                                <?php echo Form::open(['method' => 'POST','url' => ['add', $product->id],'class'=>'form-inline']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="email">Cantidad:</label>
                                    <input type="number" class="form-control" placeholder="0" name="quantity"
                                           style="width: 60px; text-align: end; margin-left:  30px;">
                                </div>

                                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 10px;">
                                    <i class="glyphicon glyphicon-shopping-cart"> </i>
                                    Agregar al carrito
                                </button>
                                <?php echo Form::Close(); ?>

                            </div>

                        </div>
                    </div>
                    <ins class="adsbygoogle"
                         style="display:inline-block;width:970px;height:90px"
                         data-ad-client="ca-pub-7543412924958320"
                         data-ad-slot="8423411310"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </aside>
            </div>
            
        </div>
    </div>

    
    <?php if($relationItems == NULL): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row row-featured" style="background-color: #e4ff005e;">
                        <div class="col-xl-12  box-title" style="background-color: yellow;">
                            <div class="inner"><h2><span>Productos </span> Relacionados </h2>
                            </div>
                        </div>

                        <div style="clear: both"></div>

                        <div class=" relative  content featured-list-row  w100">

                            <nav class="slider-nav has-white-bg nav-narrow-svg">
                                <a class="prev">
                                    <span class="nav-icon-wrap"></span>

                                </a>
                                <a class="next">
                                    <span class="nav-icon-wrap"></span>
                                </a>
                            </nav>

                            <div class="no-margin featured-list-slider ">
                                <?php $__currentLoopData = $relationItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item"><a
                                                href="<?php echo e(url('producto', array($commerce->id, $relationItem->id))); ?>">
                     <span class="item-carousel-thumb">
                    	<img class="img-responsive" src="<?php echo e($relationItem->photo); ?>" alt="img">
                     </span>
                                            <span class="item-name"> <?php echo e($relationItem->name); ?> </span>
                                            <span class="price">$ <?php echo e($relationItem->price); ?></span>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>