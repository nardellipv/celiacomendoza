<div class="right-bar bg_white">
    <h4>Dirección <span>Vendedor</span></h4>
    <div id="cd-google-map">
        <iframe
                width="100%"
                
                frameborder="0" style="border:0"
                src="https://www.google.com/maps/embed/v1/place?key=AIzaSyALYXInVytihQDVFo-eCCB1h3iq59whY0g&q=<?php echo e($commerce->address .','. $commerce->location); ?>, Mendoza"
                allowfullscreen>
        </iframe>
        <?php if($commerce->region): ?>
            <p><i class="fa fa-map-o" aria-hidden="true"></i> <?php echo e($commerce->region->name); ?></p>
        <?php endif; ?>
        <?php if($commerce->address): ?>
            <p><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($commerce->address); ?></p>
        <?php endif; ?>
        <?php if($commerce->phone): ?>
            <p><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($commerce->phone); ?></p>
        <?php endif; ?>
        <?php if($commerce->web): ?>
            <p><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php echo e($commerce->web); ?>"
                                                                 target="_blank"><?php echo e($commerce->web); ?></a></p>
        <?php endif; ?>
    </div>
</div>

<div class="right-bar bg_white">
    <h4>Contacto <span>Rápido</span></h4>
    <?php echo Form::open(['method' => 'POST','route' => ['mailcustomers', $commerce->id]]); ?>

    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <input type="text" class="form-control" placeholder="Nombre" value="<?php echo e(old('name')); ?>" name="name" required>
    </div>
    <div class="form-group">
        <input type="email" class="form-control" placeholder="E-mail" value="<?php echo e(old('email')); ?>" name="email" required>
    </div>
    <div class="form-group">
        <textarea class="form-control" name="messageCustomer" placeholder="Mensaje"
                  required><?php echo e(old('messageCustomer')); ?></textarea>
    </div>
    <div class="form-group">
        <?php echo Recaptcha::render(); ?>

    </div>
    <div class="form-group">
        <button type="submit">enviar</button>
    </div>
    <?php echo Form::Close(); ?>

</div>