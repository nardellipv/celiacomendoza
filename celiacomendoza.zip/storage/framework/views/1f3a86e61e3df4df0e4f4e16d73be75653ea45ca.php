<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php echo $__env->make('layouts._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div itemscope itemtype="http://schema.org/LocalBusiness" class="wrapper"></div>
    <!-- LOADER -->
    <div class="loader">
        <div class="cssload-svg"><img src="<?php echo e(asset('webStyle/img/42-3.gif')); ?>" alt="loading">
        </div>
    </div>
    <!--LOADER-->
    <!-- HEADER -->
<?php echo $__env->make('web.parts._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Popular Listing -->
    <?php echo $__env->make('web.parts._login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section id="popular-listing" class="p_b70 p_t70">
        <div class="container">
            <h1>Celíacos Mendoza</h1>
            <div class="row">
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <h4>LISTADO DE LOCALES Y VENDEDORES</h4>
                    <br>

                    <!-- listado de locales -->
                    <?php echo $__env->make('web.parts._companies', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 listing-rightbar">
                    <?php echo $__env->make('web.parts._region', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>
        </div>
    </section>

    <?php echo $__env->make('web.parts._features', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.parts._lastBlog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.parts._contactClient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->
    <?php echo $__env->make('web.parts._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->
    <?php echo $__env->make('layouts._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>