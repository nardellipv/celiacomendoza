<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Productos</h3>
                    <a href="" type="button" class="btn btn-default btn-rounded pull-right">Agregar Nueva Categoría</a>
                </div>
                <div class="panel-body">
                    <table class="table datatable">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Acción</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categorias.edit', $category->id)); ?>" class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                                    <?php echo Form::open(['method' => 'DELETE','route' => ['categorias.destroy', $category->id],'style'=>'display:inline']); ?>

                                    <?php echo e(Form::token()); ?>

                                    <button class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></button>
                                    <?php echo Form::Close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type='text/javascript' src='<?php echo e(asset('adminStyle/js/plugins/icheck/icheck.min.js')); ?>'></script>
    <script type="text/javascript"
            src="<?php echo e(asset('adminStyle/js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>