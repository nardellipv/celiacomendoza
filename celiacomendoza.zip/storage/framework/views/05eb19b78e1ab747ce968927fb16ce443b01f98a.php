<?php $__env->startSection('content'); ?>
    <section id="profile" class="p_b70 p_t70 bg_lightgry">
        <?php echo $__env->make('web.parts.alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('web.parts.alerts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <?php echo $__env->make('web.parts.adminClient._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div class="profile-login-bg">
                        <h2><span><i class="fa fa-check-square-o"></i></span> Editar <span>Producto</span></h2>
                        <?php echo Form::model($product, ['method' => 'PATCH','route' => ['product.update', $product->id],'style'=>'display:inline','enctype' => 'multipart/form-data']); ?>

                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label>Crear un nuevo Producto </label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>"
                                   placeholder="Nombre del producto" required>
                        </div>

                        <div class="form-group">
                            <label>Descripción</label>
                            <textarea class="form-control" name="description"
                                      placeholder="Descripción del producto"
                                      required><?php echo e($product->description); ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Categoría</label>
                                    <div class="intro">
                                        <select name="category_id" required>
                                            <option value="<?php echo e($product->category_id); ?>"> <?php echo e($product->category->name); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Precio </label>
                                    <input type="text" name="price" class="form-control" value="<?php echo e($product->price); ?>"
                                           placeholder="Precio" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>¿Activar Producto?</label>
                                    <input class="form-check-input" type="radio" name="available"
                                           id="inlineRadio1"
                                           value="YES" <?php echo e($product->available == 'YES' ? 'checked' : ''); ?>>Si
                                    <input class="form-check-input" type="radio" name="available"
                                           id="inlineRadio2"
                                           value="NO" <?php echo e($product->available == 'NO' ? 'checked' : ''); ?>>No
                                </div>
                            </div>
                            <br>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label>Imagen del Producto</label>
                                    <img src="<?php echo e(asset('images/thumbnail/products/'.($product->photo))); ?>">
                                    <input id="input-upload-img1" name="file" type="file" class="file"
                                           data-preview-file-type="text">

                                    <small id="" class="form-text text-muted">
                                        La imagen no debe superar los 2MB. Formatos admitidos jpg, png, gif
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit">Editar Producto</button>
                        </div>

                        <?php echo Form::Close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.adminClient', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>