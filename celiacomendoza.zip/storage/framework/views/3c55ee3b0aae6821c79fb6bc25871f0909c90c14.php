<?php $__env->startSection('title',' ⚠ ' . $commerce->name . ' local para celiacos'); ?>
<?php $__env->startSection('meta-description','💪 Local de comida sin TACC '.$commerce->name .' ubicado en '.$commerce->region->name .' ingresa y conoce más sobre este local'); ?>

<?php $__env->startSection('contentAbout'); ?>
    <?php echo $__env->make('web.parts._dataCommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('web.parts._aboutCommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('web.parts._shop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('web.parts._characteristicCommerce', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('web.parts._social', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.company', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>