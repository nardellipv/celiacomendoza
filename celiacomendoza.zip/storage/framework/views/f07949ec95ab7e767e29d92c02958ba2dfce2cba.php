<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Usuarios</h3>
            </div>
            <div class="panel-body">
                <table class="table datatable">
                    <thead>
                    <tr>
                        <th>Nombre Apellido</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->status); ?></td>
                            <td>
                                <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['user.destroy', $user->id],'style'=>'display:inline']); ?>

                                <?php echo e(Form::token()); ?>

                                <button class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></button>
                                <?php echo Form::Close(); ?>


                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
