<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="container">
            <div class="row">
                <div class="col-sm-5 login-box">
                    <div class="card card-default">
                        <div class="panel-intro text-center">
                            <h2 class="logo-title">
                                <!-- Original Logo will be placed here  -->
                                <span class="logo-icon">
                                    <img src="<?php echo e(asset('webStyle/img/img-logo.png')); ?>" alt="logo" width="25%">
                                </span>
                            </h2>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('password.request')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                <div class="form-group">
                                    <label for="sender-email" class="control-label">Email:</label>

                                    <div class="input-icon"><i class="icon-user fa"></i>
                                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"
                                               placeholder="Email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>

                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="sender-email" class="control-label">Contraseña:</label>

                                    <div class="input-icon"><i class="icon-lock fa"></i>
                                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                               placeholder="contraseña" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="sender-email" class="control-label">Confirmar Contraseña:</label>

                                    <div class="input-icon"><i class="icon-lock fa"></i>
                                        <input id="password-confirm" type="password" class="form-control"
                                               placeholder="confirmar contraseña" name="password_confirmation" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block">
                                        <?php echo e(__('Resetear mi contraseña')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer">
                            <p class="text-center "><a href="<?php echo e(url('login')); ?>"> Volver al login </a></p>

                            <div style=" clear:both"></div>
                        </div>
                    </div>
                    <div class="login-box-btm text-center">
                        <p> Don't have an account? <br>
                            <a href="<?php echo e(url('register')); ?>"><strong>Registrarse!</strong> </a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>