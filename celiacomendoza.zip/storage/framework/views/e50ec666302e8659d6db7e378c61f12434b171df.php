<section id="profile" class="p_b70 p_t70 bg_lightgry">
    <div class="container">
        <?php echo $__env->make('web.parts.alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('web.parts.alerts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-3 page-sidebar">
                <?php echo $__env->make('web.parts.adminClient._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <div class="col-md-9 page-content">
                <div class="inner-box">

                    <div class="table-responsive">
                        <table id="addManageTable"
                               class="table table-striped table-bordered add-manage-table table demo"
                               data-filter="#filter" data-filter-text-only="true">
                            <thead>
                            <tr>
                                <th>Foto</th>
                                <th data-sort-ignore="true">Nombre</th>
                                <th data-type="numeric">Precio</th>
                                <th>Opción</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $productsDisable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productDisable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:14%" class="add-img-td">
                                        <a href="../images/<?php echo e($commerce->name); ?>-<?php echo e($commerce->id); ?>/products/<?php echo e($productDisable->photo); ?>" target="_blank">
                                            <img class="thumbnail  img-responsive"
                                                 src="<?php echo e(asset('images/thumbnail/products/'.($productDisable->photo))); ?>"
                                                 alt="img"></a>
                                    </td>
                                    <td style="width:58%" class="ads-details-td">
                                        <div>
                                            <p><strong> <a href="#"
                                                           title="<?php echo e($productDisable->name); ?>"><?php echo e($productDisable->name); ?></a>
                                                </strong></p>

                                            <?php if($productDisable->highlight == 'YES'): ?>
                                                <p><strong> Destacado </strong></p>
                                            <?php else: ?>
                                                <p><strong> Sin Destacado </strong></p>
                                            <?php endif; ?>

                                            <?php if($productDisable->in_offer == 'YES'): ?>
                                                <p><strong> En Oferta </strong></p>
                                            <?php else: ?>
                                                <p><strong> Sin Oferta </strong></p>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="width:20%" class="price-td">
                                        <div>Precio: <strong>$ <?php echo e($productDisable->price); ?></strong></div>
                                        <?php if($productDisable->offer): ?>
                                            <div>Rebaja: <strong>$ <?php echo e($productDisable->offer); ?></strong></div>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width:10%" class="action-td">
                                        <div>
                                            <p>
                                                <a href="<?php echo e(route('product.edit', $productDisable->id)); ?>"
                                                   class="btn btn-primary btn-sm">
                                                    <i class="fa fa-edit"></i> Editar
                                                </a>
                                            </p>

                                            <p>
                                                <a href="<?php echo e(route('available', $productDisable->id)); ?>" class="btn btn-info btn-sm">
                                                    <i class=" fa fa-retweet"></i>  Activar
                                                </a>
                                            </p>

                                            <p>
                                                <?php echo Form::open(['method' => 'DELETE','route' => ['product.destroy', $productDisable->id],'style'=>'display:inline']); ?>

                                                <?php echo e(Form::token()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class=" fa fa-trash"></i> Eliminar
                                                </button>
                                                <?php echo Form::Close(); ?>

                                            </p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pagination-bar">
                            <nav aria-label="Page navigation " class="d-inline-b">
                                <?php echo $productsDisable->render(); ?>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
