<div class="details-heading heading">
    <h2 class="p_b20">Nuestras <span>Redes</span></h2>
    <div class="main text-center">
        <div class="fb-page" data-href="https://www.facebook.com/{{ $commerce->facebook }}/"
             data-tabs="timeline" data-width="1000" data-small-header="false"
             data-adapt-container-width="false" data-hide-cover="false"
             data-show-facepile="true">
            <blockquote cite="https://www.facebook.com/{{ $commerce->facebook }}/"
                        class="fb-xfbml-parse-ignore"><a
                        href="https://www.facebook.com/{{ $commerce->facebook }}/">{{ $commerce->name }}</a>
            </blockquote>
        </div>
    </div>
</div>
