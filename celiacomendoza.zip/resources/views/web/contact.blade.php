@extends('layouts.company')

@section('content')

    @include('web.parts._contact')

@endsection