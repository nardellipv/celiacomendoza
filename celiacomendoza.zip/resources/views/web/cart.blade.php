@extends('layouts.company')

@section('content')

    @include('web.parts._cart')

@endsection
