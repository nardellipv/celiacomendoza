<script src="{{ asset('webStyle/js/jquery.2.2.3.min.js') }}"></script>
<script src="{{ asset('webStyle/js/bootstrap.min.js') }}"></script>
{{--<script src="{{ asset('webStyle/js/jquery.appear.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/jquery-countTo.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/owl.carousel.min.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/jquery.fancybox.min.js') }}"></script>--}}
<script src="{{ asset('webStyle/js/bootsnav.js') }}"></script>
{{--<script src="{{ asset('webStyle/js/zelect.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/parallax.min.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/modernizr.custom.26633.js') }}"></script>--}}
{{--<script src="{{ asset('webStyle/js/jquery.gridrotator.js') }}"></script>--}}
<script src="{{ asset('webStyle/js/functions.js') }}"></script>
<span itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
<meta itemprop="addressLocality" content="Mendoza">
<meta itemprop="addressRegion" content="Mendoza">
<meta itemprop="addressCountry" content="Argentina"></span>
<meta itemprop="url" content="https://www.celiacosmendoza.com/">