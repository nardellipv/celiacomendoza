<?php

namespace celiacomendoza;

use Illuminate\Database\Eloquent\Model;

class AbleProduct extends Model
{
    public $timestamps = false;
}
