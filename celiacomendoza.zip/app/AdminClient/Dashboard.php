<?php

namespace celiacomendoza\AdminClient;

use Illuminate\Database\Eloquent\Model;

class Dashboard extends Model
{
    //
}
